package kr.co.estate.portal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Pixel 7 에뮬레이터와 Django API(같은 PC의 8001 포트)
private const val DJANGO_BASE_URL = "http://10.0.2.2:8001"

data class ServerApartment(
    val kaptCode: String,
    val name: String,
    val dong: String,
    val bjdCode: String
)

private data class RegionOption(val code: String, val name: String)

private fun encoded(value: String): String = URLEncoder.encode(value, "UTF-8")

private suspend fun getJsonArray(path: String): JSONArray = withContext(Dispatchers.IO) {
    val connection = URL("$DJANGO_BASE_URL$path").openConnection() as HttpURLConnection
    try {
        connection.requestMethod = "GET"
        connection.connectTimeout = 6000
        connection.readTimeout = 10000
        connection.setRequestProperty("Accept", "application/json")
        val status = connection.responseCode
        if (status !in 200..299) error("서버 응답 오류: HTTP $status")
        val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        JSONArray(response)
    } finally {
        connection.disconnect()
    }
}

private suspend fun getRegions(path: String): List<RegionOption> {
    val array = getJsonArray(path)
    return (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val code = item.optString("code")
        val name = item.optString("name")
        if (code.isBlank() || name.isBlank()) null else RegionOption(code, name)
    }.distinctBy { it.code }
}

private suspend fun getApartments(dongCode: String): List<ServerApartment> {
    // 기존 Django apartment_options_api: dong_code prefix로 필터링
    val array = getJsonArray("/api/apartment-options/?dong_code=${encoded(dongCode)}")
    return (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val code = item.optString("kapt_code")
        if (code.isBlank()) return@mapNotNull null
        ServerApartment(
            kaptCode = code,
            name = item.optString("kapt_name"),
            dong = item.optString("dong_name"),
            bjdCode = item.optString("bjd_code")
        )
    }.distinctBy { it.kaptCode }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> ChoiceField(
    title: String,
    value: T?,
    options: List<T>,
    titleOf: (T) -> String,
    enabled: Boolean,
    onChoose: (T) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(enabled) { if (!enabled) expanded = false }
    ExposedDropdownMenuBox(
        expanded = expanded && enabled,
        onExpandedChange = { if (enabled) expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = value?.let(titleOf) ?: "선택하십시오",
            onValueChange = {},
            readOnly = true,
            label = { Text(title) },
            enabled = enabled,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded && enabled, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(titleOf(option)) },
                    onClick = { expanded = false; onChoose(option) }
                )
            }
        }
    }
}

@Composable
fun ServerSearchScreen(onSelect: (ServerApartment) -> Unit) {
    var sidos by remember { mutableStateOf<List<RegionOption>>(emptyList()) }
    var sigungus by remember { mutableStateOf<List<RegionOption>>(emptyList()) }
    var dongs by remember { mutableStateOf<List<RegionOption>>(emptyList()) }
    var apartments by remember { mutableStateOf<List<ServerApartment>>(emptyList()) }

    var sido by remember { mutableStateOf<RegionOption?>(null) }
    var sigungu by remember { mutableStateOf<RegionOption?>(null) }
    var dong by remember { mutableStateOf<RegionOption?>(null) }
    var apartment by remember { mutableStateOf<ServerApartment?>(null) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        loading = true
        try { sidos = getRegions("/api/sidos/"); error = null }
        catch (e: Exception) { error = "시도 조회 실패: ${e.message}" }
        finally { loading = false }
    }
    LaunchedEffect(sido?.code) {
        sigungus = emptyList()
        if (sido != null) {
            loading = true
            try {
                sigungus = getRegions("/api/sigungus/?sido_code=${encoded(sido!!.code)}")
                error = null
            } catch (e: Exception) { error = "시군구 조회 실패: ${e.message}" }
            finally { loading = false }
        }
    }
    LaunchedEffect(sigungu?.code) {
        dongs = emptyList()
        if (sigungu != null) {
            loading = true
            try {
                dongs = getRegions("/api/dongs/?sigungu_code=${encoded(sigungu!!.code)}")
                error = null
            } catch (e: Exception) { error = "읍면동 조회 실패: ${e.message}" }
            finally { loading = false }
        }
    }
    LaunchedEffect(dong?.code) {
        apartments = emptyList()
        if (dong != null) {
            loading = true
            try {
                apartments = getApartments(dong!!.code)
                error = null
            } catch (e: Exception) { error = "아파트 조회 실패: ${e.message}" }
            finally { loading = false }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("전국 아파트 단지검색", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("지역과 단지를 순서대로 선택하십시오.", style = MaterialTheme.typography.bodySmall)
        ChoiceField("시도", sido, sidos, { it.name }, !loading && sidos.isNotEmpty()) {
            sido = it; sigungu = null; dong = null; apartment = null
            sigungus = emptyList(); dongs = emptyList(); apartments = emptyList()
        }
        ChoiceField("시군구", sigungu, sigungus, { it.name }, !loading && sido != null && sigungus.isNotEmpty()) {
            sigungu = it; dong = null; apartment = null
            dongs = emptyList(); apartments = emptyList()
        }
        ChoiceField("읍면동", dong, dongs, { it.name }, !loading && sigungu != null && dongs.isNotEmpty()) {
            dong = it; apartment = null; apartments = emptyList()
        }
        // 별도의 리 API가 없어 도시/농촌 모두 잘못된 리 목록을 만들어 내지 않습니다.
        // 정확한 리 목록 API 추가 시 이 위치에 '리' 선택 필드를 연결합니다.
        ChoiceField("아파트", apartment, apartments, { it.name }, !loading && dong != null && apartments.isNotEmpty()) {
            apartment = it
        }
        if (loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (!loading && dong != null && error == null) {
            Text("선택 지역 단지 ${apartments.size}개", style = MaterialTheme.typography.bodySmall)
        }
        Button(
            onClick = { apartment?.let(onSelect) },
            enabled = !loading && apartment != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("검색") }
    }
}

@Composable
fun ServerApartmentDetail(apt: ServerApartment) {
    var tab by remember(apt.kaptCode) { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            listOf("실거래", "단지정보", "중개사·매물").forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(apt.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(apt.dong)
            Text("단지코드: ${apt.kaptCode}")
            Text(when (tab) {
                0 -> "실거래 API 연결 대상 단지입니다. 다음 단계에서 실거래 내역과 그래프를 연결합니다."
                1 -> "법정동 코드: ${apt.bjdCode}. 다음 단계에서 상세 단지정보를 연결합니다."
                else -> "다음 단계에서 선택한 단지코드로 중개사 및 매물 API를 연결합니다."
            })
        }
    }
}
